package model;


import java.util.concurrent.CountDownLatch;


import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class verProducto extends conexion {
    public static String mensaje;
    public static String anterior = "";
    
    public static void main(String[] args) {
        
    }

    /**
     * inicialización de firebase.
     */
    

    public static String ver(String ruta) {
    if (ruta != null) {
        if (!iniciado) {
            initFirebase();
            iniciado = true;
        }
        
        DatabaseReference referencia = FirebaseDatabase.getInstance().getReference(ruta);
        final String[] valor = {""}; // Usamos un arreglo para almacenar el valor

        CountDownLatch countDownLatch = new CountDownLatch(1);
        referencia.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                //if (ruta.equals("items")){
                    for (DataSnapshot itemSnapshot : dataSnapshot.getChildren()) {
                        
                        String id = itemSnapshot.child("id").getValue().toString();
                        String nombre = itemSnapshot.child("nombre").getValue().toString();
                        String precio = itemSnapshot.child("precio").getValue().toString();
                        mensaje="ID: " + id + "\n" +
                                "Nombre: " + nombre + "\n" +
                                "Precio: " + precio+"\n"+
                                "-------------------------\n";
                        
                        valor[0]=anterior+mensaje;
                        
                        anterior=valor[0];
                    }
                   // }else{
                if (dataSnapshot.exists() && ruta!="items") {
                    valor[0] = dataSnapshot.getValue().toString(); 
                    //System.out.println(valor[0]); // Puedes imprimirlo o no, según tus necesidades.
                } else {
                    System.out.println("El dato no existe.");
                }
                countDownLatch.countDown();
            
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("Error en la lectura");
                countDownLatch.countDown();
            }
        });

        try {
            countDownLatch.await();
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
        
        return valor[0]; // Devolvemos el valor como una cadena
    }
    return null; // Devolvemos null si la ruta es nula o el dato no existe
    }
}