/*
 * Nombre: Juan Felipe Fajardo Garzón
 * Este programa se conecta con la base de datos y elimina un registro con una ruta específica
 */
package model;

import java.util.concurrent.CountDownLatch;


import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class eliminarProducto extends conexion {
    
    public static void main(String[] args) {
        new eliminarProducto().delete("Estudiantes");
    }
    

    /**
     * inicialización de firebase.
     */
    
    private void delete(String ruta) {
        if (ruta != null) {
            if (!iniciado) {
            initFirebase();
            iniciado = true;
        }
            DatabaseReference referencia = FirebaseDatabase.getInstance().getReference(ruta);
            CountDownLatch countDownLatch = new CountDownLatch(1);
            referencia.removeValue(new DatabaseReference.CompletionListener() {
                public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                    if (databaseError != null) {
                        System.out.println("Error al eliminar el registro");
                    } else {
                        System.out.println("Registro con ruta: "+ruta+" eliminado con éxito.");
                    }
                }
            });
            try {
                countDownLatch.await();
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }
    }
}
