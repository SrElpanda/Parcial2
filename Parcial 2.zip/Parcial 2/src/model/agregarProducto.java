
/*
 * Nombre: Juan Felipe Fajardo Garzón
 * Este programa se conecta con la base de datos y agrega un nuevo registro
 */
package model;
import modelView.producto;

import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;

import java.util.concurrent.CountDownLatch;

public class agregarProducto extends conexion {
    public static void main(String[] args) {
        
    }
    public static void agrega(int  id, int precio, String nombre){
        producto item = new producto();
        item.setId(id);
        item.setPrecio(precio);
        item.setNombre(nombre);
        new agregarProducto().saveUsingPush(item);
    }

    private void saveUsingPush(producto item) {
        
        if (item != null) {
            if (!iniciado) {
            initFirebase();
            iniciado = true;
        }
            DatabaseReference databaseReference = firebaseDatabase.getReference("/");
            DatabaseReference childReference = databaseReference.child("items");

            CountDownLatch countDownLatch = new CountDownLatch(1);
            childReference.push().setValue(item, new DatabaseReference.CompletionListener() {

                @Override
                public void onComplete(DatabaseError de, DatabaseReference dr) {
                    System.out.println("Item añadido");
                    countDownLatch.countDown();
                }
            });
            try {
                countDownLatch.await();
            } catch (InterruptedException ex) {
                ex.printStackTrace();
            }
        }
    }
}