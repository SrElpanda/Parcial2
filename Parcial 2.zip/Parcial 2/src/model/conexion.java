
package model;


import java.io.FileInputStream;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;

import com.google.firebase.database.FirebaseDatabase;
import java.io.File;
import java.io.FileNotFoundException;

public class conexion{
    public static boolean iniciado=false;
    public static FirebaseDatabase firebaseDatabase;
    public static void main(String[] args) {
        initFirebase();
    }
    public static void initFirebase() {
            try {

                FirebaseOptions firebaseOptions = new FirebaseOptions.Builder()
                        .setDatabaseUrl("https://parcial2-6335c-default-rtdb.firebaseio.com/")
                        .setServiceAccount(new FileInputStream(new File("D:\\Universidad\\POO\\Parcial 2\\auth\\clave.json")))
                        .build();

                FirebaseApp.initializeApp(firebaseOptions);
                firebaseDatabase = FirebaseDatabase.getInstance();
                //System.out.println("La conexión se realizo exitosamente...");
            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            }

    }}