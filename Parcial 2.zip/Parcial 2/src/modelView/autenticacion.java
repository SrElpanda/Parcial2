/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelView;
import model.verProducto;
/**
 *
 * @author User
 */
public class autenticacion {
    public static boolean verificar(String usuario, String contra){
        if (usuario.equals(verProducto.ver("usuario")) && contra.equals(verProducto.ver("contraseña"))){
            return true;
        }else{
            return false;
        } 
}
}
